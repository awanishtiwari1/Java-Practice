package com.company;

class test
{

    test()
    {
        System.out.println("Constructor is created");
    }

}


public class Constructor {
    public static void main(String[] args) {
//Example of automatic invoking of the constructor on creating the object
        test t = new test();
    }
}
