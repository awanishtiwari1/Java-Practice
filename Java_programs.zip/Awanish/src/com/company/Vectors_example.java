package com.company;
import java.util.*;

// The above program will cause an error while running in an IDE
// It will run with passing arguments in command prompt
public class Vectors_example {
    public static void main(String[] args) {
        Vector list = new Vector();
        int length = args.length;
        for(int i = 0 ; i < length ; i++)
        {
            list.addElement(args[i]);

        }
        //inserting element at required index
        list.insertElementAt("python",2);
        int size = list.size();
        String listA[] = new String[size];
        list.copyInto(listA);

        System.out.println("Languages entered by user are : ");
        for(int i = 0 ; i<listA.length ; i++)
        {
            System.out.println(listA[i]);


        }





    }
}
