package com.company;

class Con{

    int length;
    int breadth;
    Con(int x , int y )
    {
        length = x ;
        breadth  = y ;
        int area = length * breadth ;

    }


}


public class Constructor_example {
    public static void main(String[] args) {
        //Example of default constructor invoking

      Con c = new Con(2,3);

    }
}
