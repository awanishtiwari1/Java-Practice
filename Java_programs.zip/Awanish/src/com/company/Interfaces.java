package com.company;
//Examples of interfaces how it works

interface i1
{
    float pi = 3.14f;
    float computeArea(float x , float y);
}
class Rectangle implements i1
{
    @Override
    public float computeArea(float x, float y) {
        return (x*y);
    }
}
class circle implements i1{
    float radius = 2;

    @Override
    public float computeArea(float x, float y) {
        return (pi * radius * radius);
    }
}


public class Interfaces {
    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        circle c = new circle();

        float a = c.computeArea(10,02);
        float b = r.computeArea(45,2);
        System.out.println("Area of circle is :");
        System.out.println(a);
        System.out.println("Areaa of rectangle is : " + b);



    }
}
