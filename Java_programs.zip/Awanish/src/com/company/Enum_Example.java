package com.company;

public class Enum_Example {

    enum Days
    {
        Sunday,
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday
    }

    public static void main(String[] args) {

        for(Days d : Days.values())
        {
            //Weekend(d);

        }

//        private static void weekend(Days d )
//        {
//
//
//            if () {
//                System.out.println(d + "is a holiday ");
//            } else {
//                System.out.println(d + "is a Working Day");
//            }
//        }



        }
    }

