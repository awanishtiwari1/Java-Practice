package com.company;

public class String_manipulation {
    public static void main(String[] args) {

        StringBuffer s = new StringBuffer("Object language ");

        System.out.println("Original String : " + s );
        //Counting String length
        System.out.println("Length of string : " + s.length());

        //Accessing the characters of the string
        for(int i =  0 ;i < s.length() ;i++)
        {
            int p = i+1;
            System.out.println("Character at position " + p  + "is : " + s.charAt(i));
        }
        //Inserting in the middle of the string
        String s2 = new String(s.toString());
        int pos = s2.indexOf("language");
        s.insert(pos,"oriented ");
        System.out.println("Modified string : " + s );
        //Modifying character
        s.setCharAt(6, '-');
        System.out.println("String now is : " + s);


        //Appending at the end of string
        s.append("Improves security  ");
        System.out.println("Appended string is : " + s );



    }
}
