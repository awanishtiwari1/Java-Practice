package com.company;

class student {
    int rollno;
    void getrollno(int n )
    {
        rollno = n ;
    }
    void putrollno()
    {
        System.out.println("Roll no is " + rollno);
    }

}

class exammarks extends student
{
    float m1 ;
    float m2 ;

    void getmarks(float x , float y )
    {
        m1  = x;
        m2 = y;
    }
    void putmarks()
    {
        System.out.println("Marks obtained by the student are below  : ");
        System.out.println(m1);
        System.out.println(m2);
    }
}

interface sports
{
    int height  = 10;
    void volleyball();

}
//Class that extends all class and implements interfaces
class result extends exammarks implements sports
{
    @Override
    public void volleyball() {
        System.out.println("Launda Sport khelta hua ");
    }
    float total ;
    void display()
    {
        total = m1 + m2 ;
        putrollno();
        putmarks();
        volleyball();
        if(total <=150)
        {
            System.out.println("Launde ko khiye Mehnat kre , Nhi to ....");
        }
        else
        {
            System.out.println("Apka Launda Tarakki par hai , Khiye Jaari Rakhe ");
        }
    }


}

public class Interfaces3 {
    public static void main(String[] args) {

        result r = new result();
        r.getrollno(37);
        r.getmarks(56,89);
        r.display();





    }
}
