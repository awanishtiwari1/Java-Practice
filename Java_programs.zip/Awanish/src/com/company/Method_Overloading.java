package com.company;
// A program showing with method overloading
class area
{
    int length ;
    int breadth;
    area(int x )
    {
        int length = x ;

        System.out.println(length);
        System.out.println("Constructor with parameter 1 is invoked ");

    }
    area(int x , int y )
    {
        length = x ;
        breadth = y;
        int area = length * breadth;
        System.out.println(area);
        System.out.println("Constructor with parameter 2 is invoked ");
    }



}

public class Method_Overloading {
    public static void main(String[] args) {
        area a = new area(10);
        area b = new area(10,20);
//Here there is no need to access the methods of the class because
        // the constructor will automatically invoked and perform whatever written in program

    }
}
