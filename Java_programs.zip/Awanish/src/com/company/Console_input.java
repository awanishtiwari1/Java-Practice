package com.company;
//This program is for console input and will be thro while running in an IDE
public class Console_input {
    public static void main(String[] args) {
        System.out.println("Enter Your name ");
        String s = System.console().readLine();
        System.out.println("Your name is : " + s);

    }
}
