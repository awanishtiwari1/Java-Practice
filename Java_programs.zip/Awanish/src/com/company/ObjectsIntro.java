package com.company;

class awanish
{
    void name(){
        System.out.println("Awanish Pandit ");
    }
}


public class ObjectsIntro {
    public static void main(String[] args) {

        awanish av = new awanish();
        av.name();

    }
}
