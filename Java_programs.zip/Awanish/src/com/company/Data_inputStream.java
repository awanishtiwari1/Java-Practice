package com.company;
import java.io.DataInputStream;
public class Data_inputStream {
    public static void main(String[] args) {
        DataInputStream in = new DataInputStream(System.in);
        int n = 0 ;
        float p = 0.0f;
//We are surrounding the readline method inside a try catch block because it can throw runtime error if any hardware failures or any
        //others erro occurs
        try
        {
            System.out.println("Enter a integer no ");
            n = Integer.parseInt(in.readLine());
            System.out.println("Enter a float no ");

            p = (Float.valueOf(in.readLine()).floatValue());
        }
        catch (Exception e )
        {
            System.out.println(e);
        }
        System.out.println("Integer enetered by you is :" + n);
        System.out.println("Float enetered by you is : " + p);
    }
}
