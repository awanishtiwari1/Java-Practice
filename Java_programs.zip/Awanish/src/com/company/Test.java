package com.company;

public class Test {
    public static void main(String[] args) {
int m= 10;
        {
            int mn= 10;
        }

    }
}
