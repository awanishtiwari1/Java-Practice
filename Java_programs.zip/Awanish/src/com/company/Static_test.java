package com.company;

class test1 {
    static  int a  = 1;
    static int b = 2;
    static int c = a+b;

    void getAdd()
    {
        c = a - b;
        System.out.println(c);
    }
    void mul()
    {
        c = a * b;
        System.out.println(c);
    }
    void fin_value()
    {
        System.out.println("Final value of c is :" + c);
    }
}

public class Static_test {
    public static void main(String[] args) {

        test1 t = new test1();
        t.getAdd();
        t.mul();
        t.fin_value();


    }
}
