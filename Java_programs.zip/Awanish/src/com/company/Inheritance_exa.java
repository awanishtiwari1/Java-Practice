package com.company;

class phone {

    public void call()
    {
        System.out.println("Calling from phone ");
    }
    public void message()
    {
        System.out.println("Messaging from Phone ");
    }

}

class smartphone extends phone
{
    public void android()
    {
        System.out.println("Android smartphone is used ");
    }
    public void videocall()
    {
        System.out.println("Video calling from smartphone ");
    }


}

public class Inheritance_exa {
    public static void main(String[] args) {
        phone p = new phone();
        p.call();
        p.message();

        smartphone s = new smartphone();
        s.android();
        //Method call and message used by smartphone by using inheritance
        s.message();
        s.call();
        s.videocall();


    }
}
