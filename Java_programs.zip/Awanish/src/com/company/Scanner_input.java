package com.company;

import java.util.Scanner;

public class Scanner_input {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        int n = s.nextInt();
        System.out.println("No entered by you is :" + n);
    }
}
