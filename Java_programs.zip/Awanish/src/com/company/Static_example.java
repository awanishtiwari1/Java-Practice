package com.company;
// A program showing that a static member does not need any object creation while using it
// it can be directly used by its class name
class add
{
    static void  add (int a , int b )
    {
        int c = a;
        int d = b;
        System.out.println(a+b);
    }
}
public class Static_example {
    public static void main(String[] args) {
        add.add(10,20);
    }
}
