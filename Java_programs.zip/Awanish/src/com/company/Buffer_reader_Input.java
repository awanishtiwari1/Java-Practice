package com.company;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Buffer_reader_Input {
    public static void main(String[] args) throws IOException {

        //create buffer redaer class object
        InputStreamReader in = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(in);

        try{
            String input = br.readLine();//read line of text as string
            int n = Integer.parseInt(input);//converts the string into int

            System.out.println("Square is : " + n*n);
        }
        catch(Exception e )
        {
            System.out.println(e);
        }
        br.close();

    }
}
