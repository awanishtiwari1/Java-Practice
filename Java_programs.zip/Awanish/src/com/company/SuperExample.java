package com.company;

//A program with explaining how super method works with a constructor
class room
{
    int a ;
    room(int x )
    {
        a = x;
        System.out.println("Constructor  of room is called with value : " + a);
    }
}

class room2 extends room
{
    int b , c ;
    room2(int x , int y)
    {
        //This super method will call to its parent class or super class upper constructor with its matching argument
        super(x);
        b = x;
        c = y;
        System.out.println("Contsructor of room2  with values : " + c  + b);

    }

}




public class SuperExample {
    public static void main(String[] args) {

room r1  = new room(10);
room2 r2 = new room2(10,20);


    }
}
