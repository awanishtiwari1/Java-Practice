package com.company;

// Interfaces are used to generally perform multiple inheritance which is not possible
//and also not supported by the java classes
//An interface can implements more than ont one interfaces
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// These interfaces will contain only methods that should be implemented by the class implementing it
//Interfaces can never be used to create objects it can only be inherited and describes its methods in the class
// that is implementing it .
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
interface call
{
    void makecall();
}
interface message
{
    void message1();

}
interface videocall
{
    void videocall1();
}

interface camera
{
    void camera1();
}
//Here multiple interfaces are implemented at a time and are separeted by a comma
//untill you describe all its methods it will throw error
class android implements call,message,videocall,camera
{
// Here the "@Override"symbol comes in existance because we are implementing the method or overwriting that is defined in the
//Interfaces before

    @Override
    public void makecall()
    {
        System.out.println("Calling from Android ");
    }

    @Override
    public void message1() {
        System.out.println("Messaging from smartphone ");
    }

    @Override
    public void camera1() {
        System.out.println("Clicking pictures from the camera ");
    }

    @Override
    public void videocall1() {
        System.out.println("Making a video call from the smartphone ");
    }
}


public class Interfaces2 {
    public static void main(String[] args) {

        android a = new android();
        //Accessing all the methods of the interfaces
        a.makecall();
        a.camera1();
        a.message1();
        a.videocall1();

    }
}
